This is how we divided up our work: 

Siyu Chen:
1) Added constraints to table creations and finished load.sql to load all the data needed.

2) Furthermore, finished violate.sql, which includes all the query statements that will violate the constraints.

3) Helped fixed a bug in query.php.


Roland Zeng:
1) Wrote query.php, using mysqli functions to connect and run queries on the database

2) Wrote create.sql (without constraints - Siyu added those after I was done)

3) Wrote queries 2 & 3 in queries.sql
